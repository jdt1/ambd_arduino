#ifndef _WDT_RESET_H_
#define _WDT_RESET_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

//#define AMEBAD_BOARD

void wdt_reset(void);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif  /* _WDT_RESET_H_ */
